package com.abi.controller;

import com.abi.entity.Patient;
import com.abi.model.PatientModel;
import com.abi.model.UserModel;
import com.abi.service.UserService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes(value = {"SessionUser", "email", "serialNo"})
public class MainController {
	@Autowired
	UserService userService;
	@RequestMapping(value="/")
	public String homePage( ){
		
		
		return "login";
	}
	@RequestMapping(value="/loginRequest", method= RequestMethod.POST)
	public String getPatient(@RequestBody UserModel patientlogData,ModelMap model){
		String email=patientlogData.getEmail();
		String pass=patientlogData.getPassword();
      try{
		 PatientModel patientModel=userService.retrivePatientByEmailandPass(email,pass);
		 if(patientModel!=null){
			 model.addAttribute("serialNo",patientModel);
			 model.addAttribute("email",patientModel.getEmail());
			 model.addAttribute("SessionUser",patientModel.getUserName());
			  String mpass=patientModel.getPassword();
			  String memail=patientModel.getEmail();
			 
			if(pass.equalsIgnoreCase( mpass) && email.equalsIgnoreCase( memail)){
				String role="ADMIN";
				 return "patientmanagement";
			} 
		 }
      }catch (IndexOutOfBoundsException ioe) {
          return "erroremail";
      }
      return "erroremail";
	}
	@RequestMapping(value="rest/getEmail",method=RequestMethod.GET)
	@ResponseBody
	public Patient getPatientSessionInfo(HttpSession session){
		Patient patient=(Patient) session.getAttribute("email");
		return patient;
		
	} 
	@RequestMapping(value="UserMain/rest/getSerialNo",method=RequestMethod.GET)
	@ResponseBody
	public PatientModel getPatientSessionSerialInfo(HttpSession session){
		PatientModel patient=(PatientModel) session.getAttribute("serialNo");
		return patient;
		
	}
	@RequestMapping(value="/signup")
	public String registerPage( ){

		return "registration";
	}
	@RequestMapping(value="/login")
	public String loginPage( ){

		return "login";
	}
	@RequestMapping(value="UserMain/PatientProfile/patientlist")
	public String PatientInfodisplay( ){

		return "patientmanagement";
	}
	
	@RequestMapping(value="UserMain/PatientProfile/patientlist/patientInfo/addPatient")
	public String addPatient( ){

		return "createPatient";
	}
	   @RequestMapping(value = "/logout")
	    public String logout(HttpSession session, HttpServletRequest request) {
	        session.invalidate();
	        return "login";
	    }
}
