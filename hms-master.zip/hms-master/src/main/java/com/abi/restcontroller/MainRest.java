package com.abi.restcontroller;

import com.abi.model.PatientModel;
import com.abi.model.UserModel;
import com.abi.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MainRest {

	@Autowired
	UserService userService;



	@RequestMapping(value="UserMain/PatientProfile/patientlist/patientInfo", method=RequestMethod.GET)
	public List<PatientModel> getPatientList(){

		return userService.retrivePatient();
	}
	
	
	@RequestMapping(value="/checkEmail", method= RequestMethod.POST)
	public PatientModel getPatient(@RequestBody UserModel patientlogData){
		String checkemail=patientlogData.getEmail();
		
		return userService.retrivePatientByEmail(checkemail);
		
	}
	@RequestMapping(value="/createPatient", method=RequestMethod.POST)
	public void createPatient(@RequestBody  PatientModel PatientInfo){

		userService.createPatientByUser(PatientInfo);
	}
	@RequestMapping(value="UserMain/PatientProfile/patientlist/patientInfo/deletePatient/{serialNo}", method=RequestMethod.DELETE)
	public void deletePatient(@PathVariable("serialNo") int serialNo){

		userService.deletePatient(serialNo);
	}


}
