package com.abi.service;

import com.abi.entity.Patient;
import com.abi.model.PatientModel;
import com.abi.repository.PatientRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
public class UserService {

	@Autowired
	PatientRepository patientRepository;

	 public List<PatientModel> retrivePatient() {
		 List<Patient> patientList = patientRepository.getPatientList();
		 List<PatientModel> patientModelList = new ArrayList<>();
		 if(!patientList.isEmpty()){

		 for (Patient patient : patientList) {
			 PatientModel patientModel = new PatientModel();

			 patientModel.setEmail(patient.getEmail());
			 patientModel.setAge(patient.getAge());
			 patientModel.setDb(patient.getDb());
			 patientModel.setHealthId(patient.getHealthId());
			 patientModel.setSerialNo(patient.getSerialNo());
			 patientModel.setUserName(patient.getUserName());
			 patientModel.setPassword(patient.getPassword());
			 patientModelList.add(patientModel);

		 }
		 return patientModelList;
	 }
	return null;
	 }
	public  void createPatientByUser(PatientModel patientModel){
		Patient patient =new Patient();
		if(patientModel.getSerialNo()!=0){
			patient.setSerialNo(patientModel.getSerialNo());
		}
		if(StringUtils.hasText(patientModel.getHealthId())){
			patient.setHealthId(patientModel.getHealthId());

		}else{
			Random rnd = new Random();
			long code= (0000001 + rnd.nextInt(900000));
			String healthId="01"+"103"+code+"01";
			patient.setHealthId(healthId);
		}

		patient.setUserName(patientModel.getUserName());
		patient.setEmail(patientModel.getEmail());
		patient.setPassword(patientModel.getPassword());
		patient.setDb(patientModel.getDb());
		patient.setAge(patientModel.getAge());



		patientRepository.addpatient(patient);


	}
	public void deletePatient(int serialNo){
		patientRepository.deletePatient(serialNo);
	}


    public PatientModel retrivePatientByEmailandPass(String email, String pass) {

		Patient patient=  patientRepository.getPatientByemailandPass(email,pass);
		if(patient!=null){
			PatientModel patientModel=new PatientModel();
			patientModel.setUserName(patient.getUserName());
			patientModel.setEmail(patient.getEmail());
			patientModel.setPassword(patient.getPassword());
			patientModel.setHealthId(patient.getHealthId());
			patientModel.setSerialNo(patient.getSerialNo());
			patientModel.setAge(patient.getAge());
			return patientModel;
		}
		return  null;
    }
	public PatientModel retrivePatientByEmail(String email) {
		
		 Patient patient= patientRepository.getPatientByemail(email);

			PatientModel patientModel=new PatientModel();
		if(patientModel!=null) {
			patientModel.setUserName(patient.getUserName());
			patientModel.setEmail(patient.getEmail());
			patientModel.setAge(patient.getAge());

			return patientModel;
		}
		return  null;


	}
}
