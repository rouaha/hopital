package com.abi.repository;

import com.abi.entity.Patient;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by shahidul on 5/4/17.
 */
public interface PatientRepo extends CrudRepository<Patient,Integer> {
    @Query("select pa from Patient pa where pa.email=:emailId and pa.password=:pass")
    Patient fetchPaientByEmailAndPass(@Param("emailId") String emailId, @Param("pass") String pass);


    @Query("select pa from Patient pa where pa.email = :emailId")
    Patient fetchPaientByEmail(@Param("emailId") String emailId);
       
}
