
angular.module('myApp',[]).
controller('formCtrl', function($scope,$http,$window) {
	var baseurl="http://localhost:8084/";
    $scope.parent = {'checkOut':''};
    $scope.patientage=0;
	$scope.UserlogDetails=[];
	$scope.chekedmail='';
$scope.calculateAge= function(){
		var db=$scope.parent.checkOut;
		console.log("test db"+db);
    var birthday = new Date(db);
    var ageDifMs = Date.now() - birthday.getTime();
    var ageDate = new Date(ageDifMs); // miliseconds from epoch
     var age= Math.abs(ageDate.getUTCFullYear() - 1970);
    $scope.patientage=age;
		console.log('Test focus...'+age);

};

	$scope.regi=function(){


		var userDetails={
			"userName":$scope.Userregi.userName,
			"email":$scope.Userregi.email,
			"password":$scope.Userregi.pass,
			"healthId":"",
			"db":$scope.parent.checkOut,
			"age":$scope.patientage,
			"serialNo":'',
		};

        console.log(userDetails);
		//if(patientdata.data.email== $scope.Userregi.email){
			//window.alert("Email is already extis!")
		//}else{
			$http({
				method: 'POST',
				url: 'http://localhost:8084/createPatient',
				data:userDetails,
				headers: {
					'Content-Type': 'application/json'
				}

			}).then(function mySuccess(response) {

				console.log(userDetails);
				$window.location.href = 'http://localhost:8084/login'

			}, function myError(response) {
				$scope.myWelcome = response.statusText;
			})
		//}

		


	};
	$scope.model = {
		    isDisabled: false
		};
$scope.emailcheck=function () {
	console.log($scope.Userregi.email);
	 var emailDetails={
	            "userName":'',
	            "email":$scope.Userregi.email,
	            "password":''
	        }
    $http({
        method: 'POST',
        url: 'http://localhost:8084/checkEmail',
        data:emailDetails,

        headers: {
            'Content-Type': 'application/json'
        }

    }).then(function mySuccess(response) {
         var patientdata=response;
		$scope.chekedmail=patientdata.data.email;
       if( $scope.Userregi.email==patientdata.data.email){
    	   window.alert("Email is already extis!")
    	   console.log('true');
    	   $scope.model = {
    			    isDisabled: true
    			};
    	   
       };



    }, function myError(response) {
        $scope.myWelcome = response.statusText;
    });
    
    $scope.createNewPatient=function(){

       var locUrl='';
		var userDetails={
			"userName":$scope.Userregi.userName,
			"email":$scope.Userregi.email,
			"password":$scope.Userregi.pass,
			"healthId":"",
			"db":$scope.parent.checkOut,
			"age":$scope.patientage,
			"serialNo":'',
		};
        if($scope.checkboxModel.value1='true'){ 
        	locUrl='http://localhost:8084/UserMain/PatientProfile/patientlist';}
        else{  locUrl='http://localhost:8084/PatientProfile/patientlist/patientInfo/addPatient';}

		if(patientdata.data.email==$scope.Userregi.email){
			window.alert("Email is already extis!")
		}else{
			$http({
				method: 'POST',
				url: 'http://localhost:8084/createPatient',
				data:userDetails,
				headers: {
					'Content-Type': 'application/json'
				}

			}).then(function mySuccess(response) {

				console.log(userDetails);
				$window.location.href = locUrl;

			}, function myError(response) {
				$scope.myWelcome = response.statusText;
			})
		}

		


	};

}


});