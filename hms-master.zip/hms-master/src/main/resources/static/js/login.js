/**
 * Created by Rouaha on 5/6/2017.
 */
angular.module('myApp',[]).
controller('formCtrl', function($scope,$http,$window) {
    $scope.logincheck=function () {
        var logDetails={
            "userName":'',
            "email":$scope.log.email,
            "password":$scope.log.pass
        }
        $http({
            method: 'POST',
            url: 'http://localhost:8084/loginRequest',
            data:logDetails,
            headers: {
                'Content-Type': 'application/json'
            }

        }).then(function mySuccess(response) {

        	$window.location.href ='http://localhost:8084/UserMain/PatientProfile/patientlist';


        }, function myError(response) {
            $scope.myWelcome = response.statusText;
        })

    }
    $scope.signup=function(){
    	$window.location.href ='http://localhost:8084/signup';
         
    }
});